USE AnalisisOpinionesDW;
GO

CREATE SCHEMA stg AUTHORIZATION dbo;
GO

CREATE TABLE stg.EjecucionesExtraccion
(
    IdEjecucion BIGINT IDENTITY(1,1) NOT NULL,
    FechaInicio DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    FechaFin DATETIME2 NULL,
    Estado VARCHAR(20) NOT NULL,
    RegistrosExtraidos INT NOT NULL DEFAULT 0,
    RegistrosInsertados INT NOT NULL DEFAULT 0,
    RegistrosDuplicados INT NOT NULL DEFAULT 0,
    RegistrosRechazados INT NOT NULL DEFAULT 0,
    DuracionMs BIGINT NULL,
    MensajeError NVARCHAR(2000) NULL,

    CONSTRAINT PK_EjecucionesExtraccion PRIMARY KEY (IdEjecucion),
    CONSTRAINT CK_EjecucionesExtraccion_Estado
        CHECK (Estado IN ('EN_PROCESO', 'COMPLETADO', 'ERROR'))
);

CREATE TABLE stg.DetalleExtraccion
(
    IdDetalle BIGINT IDENTITY(1,1) NOT NULL,
    IdEjecucion BIGINT NOT NULL,
    Fuente NVARCHAR(100) NOT NULL,
    RegistrosExtraidos INT NOT NULL,
    RegistrosInsertados INT NOT NULL,
    RegistrosDuplicados INT NOT NULL,
    RegistrosRechazados INT NOT NULL,
    DuracionMs BIGINT NOT NULL,

    CONSTRAINT PK_DetalleExtraccion PRIMARY KEY (IdDetalle),
    CONSTRAINT FK_DetalleExtraccion_Ejecucion
        FOREIGN KEY (IdEjecucion)
        REFERENCES stg.EjecucionesExtraccion(IdEjecucion)
);

CREATE TABLE stg.Encuestas
(
    IdStaging BIGINT IDENTITY(1,1) NOT NULL,
    IdEjecucion BIGINT NOT NULL,
    IdOpinion VARCHAR(50) NOT NULL,
    IdCliente INT NULL,
    IdProducto INT NOT NULL,
    Fecha DATE NOT NULL,
    Comentario NVARCHAR(MAX) NOT NULL,
    Clasificacion NVARCHAR(20) NULL,
    PuntajeSatisfaccion TINYINT NULL,
    Fuente NVARCHAR(50) NOT NULL,
    FechaExtraccion DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_StgEncuestas PRIMARY KEY (IdStaging),
    CONSTRAINT UQ_StgEncuestas_Opinion UNIQUE (IdOpinion),
    CONSTRAINT FK_StgEncuestas_Ejecucion
        FOREIGN KEY (IdEjecucion)
        REFERENCES stg.EjecucionesExtraccion(IdEjecucion),
    CONSTRAINT CK_StgEncuestas_Puntaje
        CHECK (PuntajeSatisfaccion IS NULL OR PuntajeSatisfaccion BETWEEN 1 AND 5)
);

CREATE TABLE stg.ResenasWeb
(
    IdStaging BIGINT IDENTITY(1,1) NOT NULL,
    IdEjecucion BIGINT NOT NULL,
    IdReview VARCHAR(50) NOT NULL,
    IdCliente INT NULL,
    IdProducto INT NOT NULL,
    Fecha DATE NOT NULL,
    Comentario NVARCHAR(MAX) NOT NULL,
    Rating TINYINT NULL,
    FechaExtraccion DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_StgResenasWeb PRIMARY KEY (IdStaging),
    CONSTRAINT UQ_StgResenasWeb_Review UNIQUE (IdReview),
    CONSTRAINT FK_StgResenasWeb_Ejecucion
        FOREIGN KEY (IdEjecucion)
        REFERENCES stg.EjecucionesExtraccion(IdEjecucion),
    CONSTRAINT CK_StgResenasWeb_Rating
        CHECK (Rating IS NULL OR Rating BETWEEN 1 AND 5)
);

CREATE TABLE stg.ComentariosApi
(
    IdStaging BIGINT IDENTITY(1,1) NOT NULL,
    IdEjecucion BIGINT NOT NULL,
    IdComment VARCHAR(50) NOT NULL,
    IdCliente INT NULL,
    IdProducto INT NOT NULL,
    Fuente NVARCHAR(50) NOT NULL,
    Fecha DATE NOT NULL,
    Comentario NVARCHAR(MAX) NOT NULL,
    FechaExtraccion DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT PK_StgComentariosApi PRIMARY KEY (IdStaging),
    CONSTRAINT UQ_StgComentariosApi_Comment UNIQUE (IdComment),
    CONSTRAINT FK_StgComentariosApi_Ejecucion
        FOREIGN KEY (IdEjecucion)
        REFERENCES stg.EjecucionesExtraccion(IdEjecucion)
);
GO
